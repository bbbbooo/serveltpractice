package com.ohgiraffers.section01.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class App {
    public static void main(String[] args) throws IOException {

        ServerSocket serverSocket = new ServerSocket(8000);

        Socket client;
        while((client = serverSocket.accept()) != null){

            // 아래와 같은 기능
//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//
//                }
//            });

            Socket fileClient = client;
            new Thread(() -> {
                try {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(fileClient.getInputStream()));

                    String line;
                    while ((line = reader.readLine()) != null){
                        System.out.println("line = " + line);
                    }

                    reader.close();
                    fileClient.close();

                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }).start();
        }
    }
}
